<?php
	define('DB_NAME','incsmart');
	define('DB_USER','root');
	define('DB_PASSWORD','udit717');
	define('DB_HOST','localhost');
